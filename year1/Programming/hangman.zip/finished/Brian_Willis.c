/*Program to function as a hangman game
Brian Willis
Issued 30/10/2012
Due 16/11/2012
*/

#include <stdio.h>
#include <stdlib.h>
#define SIZE 10
#define LIVES 6

main()
{
	char word1[SIZE]={'L','I','T','T','E','R'};
	char word2[SIZE]={'B','E','A','N','B','A','G'};
	char word3[SIZE]={'O','P','E','N','I','N','G'};
	char word4[SIZE]={'S','E','T','T','L','E','M','E','N','T'};
	char word5[SIZE]={'P','R','O','G','R','A','M'};
	
	int lives;
	int i;
	int j;
	int truefalse;
	int random;
	int win;
	int lose;
	char guess[SIZE+LIVES];
	char chosen[SIZE];
	char input;
	int current;
	int matches;
	int wordlength;
	int correct;
	
	do
	{
		//The loop below wipes the guess array at the start of each game. It was not in my flowchart.
		for (i=0;i<SIZE+LIVES;i++)
		{
			guess[i]=0;
		}
		
		//randomly selecting a word
		srand(time(NULL));
		random=rand()%5;
		
		for(i=0;i<SIZE;i++)
		{
			switch (random)
			{
				case 0:
				{
					chosen[i]=word1[i];
					break;
				}
				case 1:
				{
					chosen[i]=word2[i];
					break;
				}
				case 2:
				{
					chosen[i]=word3[i];
					break;
				}
				case 3:
				{
					chosen[i]=word4[i];
					break;
				}
				case 4:
				{
					chosen[i]=word5[i];
				}
			}//end switch
		}// end for
	
		//resetting values
		lives=LIVES;
		win=0;
		lose=0;
		current=0;
		wordlength=0;
		matches=0;

		//finding the length of the word
		for (i=0;i<SIZE;i++)
		{
			if (chosen[i]!=0)
			{
				wordlength++;
			}//end if
		}//end for
				
		do
		{
			printf ("Lives: %d\n", lives);
			printf ("Word:");
			
			//printing what has been guessed of the word
			for (i=0;i<SIZE;i++)
			{
				truefalse=0;
				
				for (j=0;j<SIZE+LIVES;j++)
				{
					if (chosen[i]==guess[j]&&chosen[i]!=0)
					{
						printf (" %c", chosen[i]);
						truefalse=1;
					}//end if
				}//end inner for
				
				if (truefalse==0&&chosen[i]!=0)
				{
					printf (" _");
				}//end if
			}//end outer for
			
			//printing what letters have been guessed, but only if the game is still ongoing
			if (lives!=0&&wordlength!=matches)
			{
				printf ("\nLetters guessed so far:");
				
				if (guess[0]!=0)
				{
					printf ("\n");
				}//end inner if
				
				for (i=0;i<SIZE+LIVES;i++)
				{
					printf ("%c", guess[i]);
					
					if (guess[i+1]!=0&&i+1<SIZE+LIVES)
					{
						printf (",");
					}//end inner if
				}//end for
			}//end outer if
			
			//Loss condition check
			if (lives==0)
			{
				lose=1;
			}
			
			//Win condition check
			if (lose!=1&&win!=1&&wordlength==matches)
			{	
				win=1;
			}
			
			//input and calculation section
			if (lose!=1&&win!=1)
			{
				do
				{
					truefalse=0;
					
					printf ("\nGuess a Letter:\n");
					scanf ("%1s", &input);
					
					//The numbers used in the various if conditions below are from the ASCII table and are being used here to detect invalid inputs.
					if (input<48)
					{
						printf ("\nInvalid input.\n");
						truefalse=1;
					}
					
					if (input>57&&input<65)
					{
						printf ("\nInvalid input.\n");
						truefalse=1;
					}
					
					if (input>90&&input<97)
					{
						printf ("\nInvalid input.\n");
						truefalse=1;
					}
					
					if (input>122)
					{
						printf ("\nInvalid input.\n");
						truefalse=1;
					}
					
					//Converting lower case input to upper case
					if (truefalse==0)
					{
						if (input>96&&input<123)
						{
							input=input-32;
						}
					}//end outer if
					
					//checking if the input has already been guessed
					for (i=0;i<SIZE+LIVES;i++)
					{
						if (input==guess[i])
						{
							printf ("\nInvalid input.\n");
							truefalse=1;
						}//end if
					}//end for
					
					//if the input was valid, moves onto the next element in the guess array
					if (truefalse==0)
					{
						guess[current]=input;
						current++;
						printf ("\n");
						//This printf statement is for spacing each round apart.
					}
					
					//checking how many letters have been guessed
					matches=0;
					
					for (i=0;i<SIZE;i++)
					{
						for (j=0;j<SIZE+LIVES;j++)
						{
							if (chosen[i]==guess[j]&&chosen[i]!=0)
							{
								matches++;
							}//end if
						}//end inner for
					}//end outer for
					
					//checking how many lives have been lost
					lives=LIVES;
					
					for (i=0;i<SIZE+LIVES;i++)
					{
						correct=0;
						
						for (j=0;j<SIZE;j++)
						{
							if (guess[i]==chosen[j])
							{
								correct=1;
							}//end if
						}//end inner for
						
						if (correct==0&&guess[i]!=0)
						{
							lives=lives-1;
						}//end if
					}//end outer for
				}
				while (truefalse==1);//end do while for only accepting valid input
			}//end if for input and calculation
		}
		while (win!=1&&lose!=1);//end do while for playing the game
		
		//printing a message for winning or losing
		if (win==1)
		{
			printf ("\nCongratulations, you won.");
		}
		else if (lose==1)
		{
			printf ("\nSorry, you lost.\nThe word was:\n");
			
			for (i=0;i<SIZE;i++)
			{
				printf ("%c", chosen[i]);
			}
		}//end if
		
		//asking whether to play again
		truefalse=0;
		
		do
		{
			printf ("\nPlay again? Y/N\n");
			scanf ("%1s", &input);
			
			switch (input)
			{
				case 'Y':
				{
					truefalse=1;
					printf ("\n");
					break;
				}
				case 'y':
				{
					truefalse=1;
					printf ("\n");
					break;
				}
				case 'N':
				{
					truefalse=1;
					break;
				}
				case 'n':
				{
					truefalse=1;
					break;
				}
				default:
				{
					printf ("\nInvalid input.\n");
				}
			}//end switch
		}
		while (truefalse==0);//end do while for user's decision whether to restart
	}
	while (input=='y'||input=='Y');//end do while for restarting
}//end main()